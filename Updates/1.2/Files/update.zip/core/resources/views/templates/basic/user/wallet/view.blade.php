@extends($activeTemplate . 'layouts.master')
@section('content')
@php
    $walletBalance  = showAmount($wallet->balance);
    $transferCharge = getAmount($general->transfer_charge);
@endphp
    <div class="row gy-3 justify-content-center mb-3">
        <div class="col-lg-12">
            <div class="d-flex flex-wrap flex-between align-items-center">
                <h4 class="mb-0">{{ __($pageTitle) }}</h4>
                <a href="{{ route('user.wallet.list') }}" class="btn btn--base btn--sm outline">
                    <i class="la la-undo"></i> @lang('Back')
                </a>
            </div>
        </div>
    </div>
    <div class="row gy-4 mb-3 justify-content-center">
        <div class="col-xxl-3 col-sm-6">
            <div class="dashboard-card ">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="dashboard-card__icon text--base">
                        <i class="las la-spinner"></i>
                    </span>
                    <div class="dashboard-card__content">
                        <a href="{{ route('user.order.open') }}?currency={{ $currency->symbol }}"
                            class="dashboard-card__coin-name mb-0 ">
                            @lang('Open Order')
                        </a>
                        <h6 class="dashboard-card__coin-title"> {{ getAmount(@$widget['open_order']) }} </h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xxl-3 col-sm-6">
            <div class="dashboard-card ">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="dashboard-card__icon text--success">
                        <i class="las la-check-circle"></i>
                    </span>
                    <div class="dashboard-card__content">
                        <a href="{{ route('user.order.completed') }}?currency={{ $currency->symbol }}" class="dashboard-card__coin-name mb-0">
                            @lang('Completed Order')
                        </a>
                        <h6 class="dashboard-card__coin-title"> {{ getAmount(@$widget['completed_order']) }}
                        </h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xxl-3 col-sm-6">
            <div class="dashboard-card ">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="dashboard-card__icon text--danger">
                        <i class="las la-times-circle"></i>
                    </span>
                    <div class="dashboard-card__content">
                        <a href="{{ route('user.order.canceled') }}?currency={{ $currency->symbol }}" class="dashboard-card__coin-name mb-0 ">
                            @lang('Canceled Order')
                        </a>
                        <h6 class="dashboard-card__coin-title"> {{ getAmount(@$widget['canceled_order']) }}</h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xxl-3 col-sm-6">
            <div class="dashboard-card">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="dashboard-card__icon text--base fs-50 icon-order"></span>
                    <div class="dashboard-card__content">
                        <a href="{{ route('user.order.history') }}?search={{ @$currency->symbol }}"
                            class="dashboard-card__coin-name mb-0">
                            @lang('Total Order')
                        </a>
                        <h6 class="dashboard-card__coin-title">
                            {{ getAmount($widget['total_order']) }}
                        </h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row gy-3 mb-3 justify-content-center">
        <div class="col-xxl-3 col-sm-6">
            <div class="dashboard-card">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="dashboard-card__icon text--base fs-50 icon-deposit"></span>
                    <div class="dashboard-card__content">
                        <a href="{{ route('user.deposit.history') }}?search={{ @$currency->symbol }}" class="dashboard-card__coin-name mb-0">
                            @lang('Total Deposit')
                        </a>
                        <h6 class="dashboard-card__coin-title">
                            {{ __(@$wallet->currency->sign) }}{{ showAmount($widget['total_deposit']) }}
                        </h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xxl-3 col-sm-6">
            <div class="dashboard-card">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="dashboard-card__icon text--base fs-50 icon-withdraw">
                    </span>
                    <div class="dashboard-card__content">
                        <a href="{{ route('user.withdraw.history') }}?search={{ @$currency->symbol }}" class="dashboard-card__coin-name mb-0 ">
                            @lang('Total Withdraw')
                        </a>
                        <h6 class="dashboard-card__coin-title">
                            {{ __(@$wallet->currency->sign) }}{{ showAmount($widget['total_withdraw']) }}
                        </h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xxl-3 col-sm-6">
            <div class="dashboard-card">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="dashboard-card__icon text--base fs-50 icon-transaction"></span>
                    <div class="dashboard-card__content">
                        <a href="{{ route('user.transactions') }}?symbol={{ @$currency->symbol }}" class="dashboard-card__coin-name mb-0">
                            @lang('Total Transaction')
                        </a>
                        <h6 class="dashboard-card__coin-title">
                            {{ getAmount($widget['total_transaction']) }}
                        </h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xxl-3 col-sm-6">
            <div class="dashboard-card ">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="dashboard-card__icon text--base">
                        <span class="icon-trade fs-50"></span>
                    </span>
                    <div class="dashboard-card__content">
                        <a href="{{ route('user.trade.history') }}" class="dashboard-card__coin-name mb-0">@lang('Total Trade') </a>
                        <h6 class="dashboard-card__coin-title"> {{ getAmount(@$widget['total_trade']) }} </h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row gy-3 mb-3 justify-content-center">
        <div class="col-lg-12 col-xl-4">
            <div class="card border-0 mb-3">
                <div class="card-body">
                    <div class="wallet-currency text-center mb-3">
                        <img src="{{ @$wallet->currency->image_url }}">
                        <div class="">
                            <p class="mb-0 fs-16">{{ __(@$wallet->currency->name) }}</p>
                            <p class="mt-0 fs-12">{{ __(@$wallet->currency->symbol) }}</p>
                        </div>
                    </div>
                    <div class="wallet-ballance p-3 mb-3">
                        <p class="mb-0 fs-16">{{ __(@$wallet->currency->sign) }}{{ showAmount($wallet->balance) }}
                        </p>
                        <p class="mt-0 fs-12">@lang('Available Balance')</p>
                    </div>
                    <div class="d-flex flex-wrap gap-2 mb-3">
                        <div class="flex-fill wallet-ballance p-3 mt-3">
                            <p class="mb-0 fs-16">
                                {{ __(@$wallet->currency->sign) }}{{ showAmount($wallet->in_order) }}</p>
                            <p class="mt-0 fs-12">@lang('In Order')</p>
                        </div>
                        <div class="flex-fill wallet-ballance p-3 mt-3 ">
                            <p class="mb-0 fs-16">
                                {{ __(@$wallet->currency->sign) }}{{ showAmount($wallet->total_balance) }}</p>
                            <p class="mt-0 fs-12">@lang('Total Balance')</p>
                        </div>
                    </div>
                    <div class="d-flex flex-wrap gap-2 ">
                        <button type="button" class="btn btn--success outline flex-fill btn--sm depositBtn">
                            <span class="icon-deposit"></span> @lang('Deposit')
                        </button>
                        <button type="button" class="btn btn--danger outline flex-fill btn--sm withdrawBtn">
                            <span class="icon-withdraw"></span> @lang('Withdraw')
                        </button>
                        <button type="button" class="btn btn--base outline flex-fill btn--sm transferBtn w-100">
                            <i class="fas fa-comments-dollar"></i> @lang('Transfer')
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12 col-xl-8">
            <div class="card custom--card border-0">
                <div class="card-body p-0">
                    <h4 class="card-title">@lang('Transaction History')</h4>
                    <table class="table table--responsive--lg">
                        <thead>
                            <tr>
                                <th>@lang('Transacted')</th>
                                <th>@lang('Trx')</th>
                                <th>@lang('Amount')</th>
                                <th>@lang('Post Balance')</th>
                                <th>@lang('Detail')</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($transactions as $trx)
                                <tr>
                                    <td>
                                        <div>
                                            {{ showDateTime($trx->created_at) }}<br>{{ diffForHumans($trx->created_at) }}
                                        </div>
                                    </td>
                                    <td>
                                        <strong>{{ $trx->trx }}</strong>
                                    </td>
                                    <td class="budget">
                                        <span
                                            class="fw-bold @if ($trx->trx_type == '+') text--success @else text--danger @endif">
                                            {{ $trx->trx_type }} {{ showAmount($trx->amount) }}
                                            {{ __($trx->wallet->currency->symbol) }}
                                        </span>
                                    </td>
                                    <td class="budget"> {{ showAmount($trx->post_balance) }}
                                        {{ __($trx->wallet->currency->symbol) }}
                                    </td>
                                    <td>{{ __($trx->details) }}</td>
                                </tr>
                            @empty
                                @php echo userTableEmptyMessage('transaction') @endphp
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
            @if ($transactions->hasPages())
                {{ paginateLinks($transactions) }}
            @endif
        </div>
    </div>

    <x-flexible-view :view="$activeTemplate . 'user.components.canvas.deposit'" :meta="['gateways' => $gateways, 'single_currency' => $currency]" />
    <x-flexible-view :view="$activeTemplate . 'user.components.canvas.withdraw'" :meta="['withdrawMethods' => $withdrawMethods, 'single_currency' => $currency]" />

    <div class="offcanvas offcanvas-end p-5" tabindex="-1" id="transfer-offcanvas" aria-labelledby="offcanvasLabel">
        <div class="offcanvas-header">
            <h4 class="mb-0 fs-18 offcanvas-title">
                @lang("Transfer $currency->symbol")
            </h4>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close">
                <i class="fa fa-times-circle"></i>
            </button>
        </div>
        <div class="offcanvas-body">
            <p class="border--base p-3 mb-3 rounded border">
                @lang("Fund transfer of $currency->symbol within the $general->site_name platform, allowing for the allocation of a maximum of $walletBalance $currency->symbol to another user, while bearing in mind a nominal $transferCharge% transaction fee.")
            </p>
            <form action="{{ route('user.wallet.transfer') }}" method="post">
                @csrf
                <input type="hidden" name="currency" value="{{ $currency->id }}">
                <div class="form-group">
                    <label class="form-label">@lang('Username')</label>
                    <input type="text" class="form--control form-control" name="username" required>
                </div>
                <div class="form-group">
                    <label class="form-label">@lang('Amount')</label>
                    <div class="input-group">
                        <input type="number" step="any" class="form--control form-control" name="transfer_amount" required>
                        <span class="input-group-text text-white">{{ __(@$currency->symbol) }}</span>
                    </div>
                </div>
                <div class="form-group transfer-details d-none">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex flex-wrap justify-content-between">
                            <span>@lang('Amount')</span>
                            <span>
                                <span class="transfer-amount"></span>
                                <span>{{ $currency->symbol }}</span>
                            </span>
                        </li>
                        <li class="list-group-item d-flex flex-wrap justify-content-between">
                            <span>@lang('Charge')</span>
                            <span>
                                <span class="transfer-charge"></span>
                                <span>{{ $currency->symbol }}</span>
                                <span class="fs-12">({{ $transferCharge }}%)</span>
                            </span>
                        </li>
                        <li class="list-group-item d-flex flex-wrap justify-content-between">
                            <span>@lang('Amount with charge')</span>
                            <span>
                                <span class="transfer-total-amount"></span>
                                <span>{{ $currency->symbol }}</span>
                            </span>
                        </li>
                    </ul>
                </div>
                <button class="btn btn--base w-100" type="submit"> @lang('Submit') </button>
            </form>
        </div>
    </div>
@endsection


@push('script')
    <script>
        "use strict";
        (function($) {

            $('.depositBtn').on('click', function(e) {
                canvasShow("deposit-canvas");
            });

            $('.withdrawBtn').on('click', function(e) {
                canvasShow("withdraw-offcanvas");
            });

            $('.transferBtn').on('click', function(e) {
                canvasShow("transfer-offcanvas");
            });

            function canvasShow(id) {
                let myOffcanvas = document.getElementById(id);
                new bootstrap.Offcanvas(myOffcanvas).show();
            }

            $("#transfer-offcanvas input[name=transfer_amount]").on('input', function() {

                let amount = parseFloat($(this).val());

                if (!amount || amount <= 0) {
                    $('.transfer-details').addClass('d-none');
                    return;
                }

                let chargePercent = parseFloat("{{ $transferCharge }}");
                let chargeAmount  = (amount / 100) * chargePercent;
                let totalAmount   = amount + chargeAmount;

                $('.transfer-amount').text(getAmount(amount));
                $('.transfer-charge').text(getAmount(chargeAmount));
                $('.transfer-total-amount').text(getAmount(totalAmount));
                $('.transfer-details').removeClass('d-none');
            });

        })(jQuery);
    </script>
@endpush

@push('style')
    <style>
        .wallet-currency img {
            width: 70px;
            border-radius: 50%;
            object-fit: cover;
        }
        .wallet-ballance {
            background-color: #09171a;
        }
    </style>
@endpush
