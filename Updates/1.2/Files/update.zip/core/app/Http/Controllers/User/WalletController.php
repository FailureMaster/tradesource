<?php

namespace App\Http\Controllers\User;

use App\Constants\Status;
use App\Models\Wallet;
use App\Models\Currency;
use App\Http\Controllers\Controller;
use App\Models\Deposit;
use App\Models\GatewayCurrency;
use App\Models\Order;
use App\Models\Trade;
use App\Models\Transaction;
use App\Models\User;
use App\Models\Withdrawal;
use App\Models\WithdrawMethod;
use Illuminate\Http\Request;

class WalletController extends Controller
{
    public function list($type = null)
    {
        $pageTitle = "My Wallets";
        $query     = $this->walletQuery()->groupBy('wallets.id');
        $typeList  = [
            'crypto' => ['crypto', "My Crypto Wallets"],
            'fiat'   => ['fiat', "My Fiat Currency Wallets"],
        ];
        if (array_key_exists($type, $typeList)) {
            [$method, $pageTitle] = $typeList[$type];
            $query->whereHas('currency', fn ($q) => $q->$method());
        }
        $wallets = $query->orderBy('balance', 'desc')->paginate(getPaginate());
        return view($this->activeTemplate . 'user.wallet.list', compact('pageTitle', 'wallets'));
    }

    public function view($curSymbol)
    {

        $currency  = Currency::where('symbol', $curSymbol)->firstOrFail();
        $wallet    = $this->walletQuery()->where('wallets.currency_id', $currency->id)->firstOrFail();
        $pageTitle = $curSymbol . " Wallet";
        $user      = auth()->user();

        $trxQuery     = Transaction::where('wallet_id', $wallet->id)->with('wallet.currency');
        $transactions = (clone $trxQuery)->latest('id')->paginate(getPaginate());
        $orderQuery   = Order::where('user_id', $user->id);
        $orderQuery   = currencyWiseOrderQuery($orderQuery, $currency);

        $widget['total_order']     = (clone $orderQuery)->count();
        $widget['open_order']      = (clone $orderQuery)->open()->count();
        $widget['completed_order'] = (clone $orderQuery)->completed()->count();
        $widget['canceled_order']  = (clone $orderQuery)->canceled()->count();

        $widget['total_deposit']     = Deposit::successful()->where('wallet_id', $wallet->id)->sum('amount');
        $widget['total_withdraw']    = Withdrawal::approved()->where('wallet_id', $wallet->id)->sum('amount');
        $widget['total_transaction'] = (clone $trxQuery)->count();

        $gateways = GatewayCurrency::where('currency', $curSymbol)->whereHas('method', function ($gate) {
            $gate->active();
        })->with('method')->get();

        $withdrawMethods       = WithdrawMethod::active()->where('currency', $curSymbol)->get();
        $widget['total_trade'] = Trade::where('trader_id', $user->id)->whereHas('order', function ($q) use ($currency) {
            $q = currencyWiseOrderQuery($q, $currency);
        })->count();

        return view($this->activeTemplate . 'user.wallet.view', compact('pageTitle', 'wallet', 'widget', 'transactions', 'gateways', 'withdrawMethods', 'currency'));
    }

    public function transfer(Request $request)
    {
        $request->validate([
            'transfer_amount' => 'required|numeric|gte:0',
            'username'        => 'required',
            'currency'        => 'required'
        ]);

        $from      = auth()->user();
        $to        = User::active()->where('username', $request->username)->firstOrFail();
        $currency  = Currency::active()->where('id', $request->currency)->firstOrFail();
        $getAmount = getAmount($request->transfer_amount);

        if ($to->id == $from->id) {
            $notify[] = ['error', "You can\t transfer $getAmount $currency->symbol to your own wallet"];
            return back()->withNotify($notify);
        }

        $fromWallet = Wallet::where('user_id', $from->id)->where('currency_id', $currency->id)->firstOrFail();
        $toWallet   = Wallet::where('user_id', $to->id)->where('currency_id', $currency->id)->firstOrFail();

        $amount        = $request->transfer_amount;
        $chargePercent = gs('transfer_charge');
        $chargeAmount  = ($amount / 100) * $chargePercent;
        $totalAmount   = $amount + $chargeAmount;

        if ($totalAmount > $fromWallet->balance) {
            $notify[] = ['error', "You do not have sufficient balance for transfer."];
            return back()->withNotify($notify);
        }

        $trx     = getTrx();
        $details = "transfer $getAmount $currency->symbol to $to->username";
        $this->createTransferTrx($trx, $from, $fromWallet, $amount, "-", $details);

        notify($from, 'TRANSFER_MONEY', [
            'amount'      => showAmount($amount),
            'charge'      => showAmount($chargeAmount),
            'trx'         => $trx,
            'currency'    => @$currency->symbol,
            'to_username' => $to->username
        ]);

        $details = "charge for transfer $getAmount $currency->symbol to $to->username";
        $this->createTransferTrx($trx, $from, $fromWallet, $chargeAmount, "-", $details);
        $this->createTransferTrx($trx, $to, $toWallet, $amount, "+", "received $getAmount $currency->symbol from  $from->username");

        notify($to, 'RECEIVED_MONEY', [
            'amount'        => showAmount($amount),
            'charge'        => showAmount($chargeAmount),
            'trx'           => $trx,
            'currency'      => @$currency->symbol,
            'from_username' => $from->username
        ]);

        $notify[] = ['success', "$getAmount $currency->symbol transfer successfully"];
        return back()->withNotify($notify);
    }

    private function createTransferTrx($trx, $user, $wallet, $amount, $type, $details)
    {
        if ($type == '+') {
            $wallet->balance += $amount;
        } else {
            $wallet->balance -= $amount;
        }
        $wallet->save();

        $transaction               = new Transaction();
        $transaction->user_id      = $user->id;
        $transaction->wallet_id    = $wallet->id;
        $transaction->amount       = $amount;
        $transaction->post_balance = $wallet->balance;
        $transaction->charge       = 0;
        $transaction->trx_type     = $type;
        $transaction->details      = $details;
        $transaction->trx          = $trx;
        $transaction->remark       = 'transfer';
        $transaction->save();
    }

    private function walletQuery(){

        return Wallet::with('currency')
        ->where('wallets.user_id', auth()->id())
        ->select('wallets.*')
        ->leftJoin('orders', function ($join) {
            $join->on('wallets.currency_id', '=', \DB::raw('CASE WHEN orders.order_side = '.Status::BUY_SIDE_ORDER.' THEN orders.market_currency_id ELSE orders.coin_id END'))
            ->where('orders.user_id',auth()->id())->where('orders.Status',Status::ORDER_OPEN);
        })
        ->selectRaw('SUM(CASE WHEN orders.order_side = ? THEN ((orders.amount-orders.filled_amount)*orders.rate) ELSE (orders.amount-orders.filled_amount) END) as in_order', [Status::BUY_SIDE_ORDER]);
    }
}
