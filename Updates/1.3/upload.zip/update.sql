ALTER TABLE `wallets` ADD `wallet_type` INT(10) UNSIGNED NOT NULL DEFAULT '0' AFTER `balance`;
UPDATE `wallets` SET wallet_type = 1;

INSERT INTO `wallets` (user_id,currency_id,wallet_type) SELECT wallets.user_id,wallets.currency_id,2 FROM wallets WHERE wallets.wallet_type=1;

ALTER TABLE `general_settings` ADD `wallet_types` TEXT NULL DEFAULT NULL AFTER `transfer_charge`;

UPDATE  `general_settings` SET `wallet_types`='{\"spot\":{\"name\":\"spot\",\"title\":\"Spot Wallets\",\"type_value\":1,\"description\":\"Users store assets available for immediate trading, configured below for various trading or transaction activities.\",\"configuration\":{\"deposit\":{\"name\":\"deposit\",\"title\":\"Deposit Fund\",\"status\":1,\"description\":\"If you enable this module, users will deposit funds to this type of wallet.\"},\"withdraw\":{\"name\":\"withdraw\",\"title\":\"Withdraw Fund\",\"status\":1,\"description\":\"If you enable this module, users can withdraw their funds from this type of wallet.\"},\"transfer_other_user\":{\"name\":\"transfer_other_user\",\"title\":\"Transfer Fund To Other Users\",\"status\":1,\"description\":\"If you enable this module, users transfer funds from this type of wallet to other users on the platform.\"},\"transfer_other_wallet\":{\"name\":\"transfer_other_wallet\",\"title\":\"Transfer Fund To Other Wallet\",\"status\":1,\"description\":\"If you enable this module, users transfer funds from this type of wallet to other wallet on the platform.\"}},\"for_fait\":0,\"for_crypto\":1,\"for_fiat\":1},\"funding\":{\"name\":\"funding\",\"title\":\"Funding Wallets\",\"type_value\":2,\"description\":\" Reserves for deposits and funding activities, configured below for various transaction activities.\",\"configuration\":{\"deposit\":{\"name\":\"deposit\",\"title\":\"Deposit Fund\",\"status\":1,\"description\":\"If you enable this module, users will deposit funds to this type of wallet.\"},\"withdraw\":{\"name\":\"withdraw\",\"title\":\"Withdraw Fund\",\"status\":1,\"description\":\"If you enable this module, users can withdraw their funds from this type of wallet.\"},\"transfer_other_user\":{\"name\":\"transfer_other_user\",\"title\":\"Transfer Fund To Other Users\",\"status\":1,\"description\":\"If you enable this module, users transfer funds from this type of wallet to other users on the platform.\"},\"transfer_other_wallet\":{\"name\":\"transfer_other_wallet\",\"title\":\"Transfer Fund To Other Wallet\",\"status\":1,\"description\":\"If you enable this module, users transfer funds from this type of wallet to other wallet on the platform.\"}},\"for_fait\":0,\"for_crypto\":1,\"for_fiat\":1}}';

ALTER TABLE `general_settings` CHANGE `transfer_charge` `other_user_transfer_charge` DECIMAL(5,2) NOT NULL DEFAULT '0.00';
ALTER TABLE `currency_data_providers` CHANGE `is_default` `is_default` TINYINT(1) NOT NULL DEFAULT '1';
ALTER TABLE `currency_data_providers` ADD `instruction` TEXT NULL DEFAULT NULL AFTER `is_default`;

UPDATE `currency_data_providers` SET `instruction` = '<ul class=\"list-group list-group-flush\">\n <li class=\"list-group-item\">Go to the CoinMarketCap website <a href=\"https://coinmarketcap.com/api\" target=\"_blank\">https://coinmarketcap.com/api</a></li>\n <li class=\"list-group-item\">Signup this platform or login existing account</li>\n <li class=\"list-group-item\">After logging into your CoinMarketCap account, Choose an API Plan</li>\n <li class=\"list-group-item\">Generate an API Key</li>\n <li class=\"list-group-item\">Copy API key & configure here</li>\n </ul>' WHERE `currency_data_providers`.`id` = 1;


INSERT INTO `currency_data_providers` (`id`, `name`, `alias`, `configuration`, `type`, `status`, `help`, `image`, `is_default`, `instruction`, `created_at`, `updated_at`) VALUES
(2, 'Cryptocompare', 'Cryptocompare', '{\"api_key\":{\"title\":\"API Key\",\"value\":\"6ba83d09cbc25dd6bbfeb5cebc615973f95184cb4e9b2e86894a0e7ea2978a53\"}}', 1, 1, NULL, 'cryptocompare.jpg', 0, ' <ul class=\"list-group list-group-flush\">\n                        <li class=\"list-group-item\">Go to the Cryptocompare website <a href=\"https://min-api.cryptocompare.com/\" target=\"_blank\">https://min-api.cryptocompare.com/</a></li>\n                        <li class=\"list-group-item\">Signup this platform or login to the existing account</li>\n                        <li class=\"list-group-item\">After logging into your Cryptocompare account, Choose an API Plan</li>\n                        <li class=\"list-group-item\">Generate an API Key</li>\n                        <li class=\"list-group-item\">Copy API key & configure here</li>\n                    </ul>', NULL, '2023-12-12 09:30:55');

ALTER TABLE `market_data` CHANGE `currency_id` `currency_id` INT(10) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE `wallets` CHANGE `user_id` `user_id` INT(10) UNSIGNED NOT NULL DEFAULT '0', CHANGE `currency_id` `currency_id` INT(10) UNSIGNED NOT NULL DEFAULT '0', CHANGE `wallet_type` `wallet_type` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0';

INSERT INTO `pages` (`id`, `name`, `slug`, `tempname`, `secs`, `is_default`, `created_at`, `updated_at`) VALUES (NULL, 'p2p', 'p2p', 'templates.basic.', NULL, '0', NULL, NULL);

ALTER TABLE `general_settings` CHANGE `metamask_login` `metamask_login` TINYINT(1) NOT NULL DEFAULT '1';
ALTER TABLE `users` ADD `image` TEXT NULL DEFAULT NULL AFTER `provider`;
ALTER TABLE `currencies` ADD `p2p_sn` INT NOT NULL DEFAULT '0' AFTER `highlighted_coin`;
ALTER TABLE `general_settings` ADD `p2p_trade_charge` DECIMAL(5,2) NOT NULL DEFAULT '0' AFTER `metamask_login`;

-- ====================== P2P ========================
CREATE TABLE `p2p_ads` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=buy,2=sell',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `asset_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `fiat_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `payment_window_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `price_type` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=Price type fixed,2=price type margin',
  `price` decimal(28,8) NOT NULL DEFAULT 0.00000000,
  `price_margin` decimal(5,2) NOT NULL DEFAULT 0.00,
  `minimum_amount` decimal(28,8) NOT NULL DEFAULT 0.00000000,
  `maximum_amount` decimal(28,8) NOT NULL DEFAULT 0.00000000,
  `payment_details` longtext DEFAULT NULL,
  `terms_of_trade` longtext DEFAULT NULL,
  `auto_reaply_text` longtext DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0=disbale,1=enable',
  `complete_step` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `p2p_ads` ADD PRIMARY KEY (`id`);
ALTER TABLE `p2p_ads` MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

CREATE TABLE `p2p_ad_payment_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ad_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `payment_method_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


ALTER TABLE `p2p_ad_payment_methods` ADD PRIMARY KEY (`id`);
ALTER TABLE `p2p_ad_payment_methods` MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

CREATE TABLE `p2p_payment_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `supported_currency` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=Active,0=Inactive',
  `form_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `branding_color` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `p2p_payment_methods`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `p2_p_payment_methods_name_unique` (`name`),
  ADD UNIQUE KEY `p2_p_payment_methods_slug_unique` (`slug`);

ALTER TABLE `p2p_payment_methods` MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

CREATE TABLE `p2p_payment_windows` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `minute` int(11) DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `p2p_payment_windows`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `p2_p_payment_windows_name_unique` (`minute`);

ALTER TABLE `p2p_payment_windows` MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

CREATE TABLE `p2p_trades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uid` varchar(255) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1=buy,2=sell',
  `ad_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `buyer_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `seller_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `payment_method_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `payment_window_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `asset_amount` decimal(28,8) NOT NULL DEFAULT 0.00000000,
  `fiat_amount` decimal(28,8) NOT NULL DEFAULT 0.00000000,
  `price` decimal(28,8) NOT NULL DEFAULT 0.00000000,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=pending,1=completed,2=please relase,3=Reported,9=cancel',
  `charge` decimal(28,8) NOT NULL DEFAULT 0.00000000,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `p2p_trades` ADD PRIMARY KEY (`id`);
ALTER TABLE `p2p_trades` MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

CREATE TABLE `p2p_trade_feed_backs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `provide_by` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1=Positive,0=Negative',
  `trade_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `p2p_trade_feed_backs` ADD PRIMARY KEY (`id`);
ALTER TABLE `p2p_trade_feed_backs` MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

CREATE TABLE `p2p_trade_messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `trade_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sender_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `receiver_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `admin_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `message` longtext DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `p2p_trade_messages` ADD PRIMARY KEY (`id`);
ALTER TABLE `p2p_trade_messages` MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;


CREATE TABLE `p2p_user_payment_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `payment_method_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `user_data` text DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `p2p_user_payment_methods` ADD PRIMARY KEY (`id`);
ALTER TABLE `p2p_user_payment_methods` MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;


INSERT INTO `notification_templates` (`act`, `name`, `subj`, `email_body`, `sms_body`, `shortcodes`, `email_status`, `sms_status`, `created_at`, `updated_at`) VALUES
('P2P_TRADE_CANCELED', 'P2P Trade Canceled', 'Canceled On Your Trade', '<div>Canceled On Your Trade. Below are the trade Details</div><div><br></div><div>Order ID: {{order_id}},</div><div>Asset Amount: {{asset_amount}},</div><div>Fiat Amount: {{fiat_amount}},</div><div>Date: {{date}}<br></div>', 'Canceled On Your Trade. Below are the trade Details', '  {\"order_id\":\"Order ID of the trade\",\"asset_amount\":\"Buy/Sell asset amount\",\"fiat_amount\":\"Trade with this fiat amount\",\"asset\" :\"crypto currency symbol\",\"fiat\" :\"Fiat Currency Symbol\",\"date\":\"Trade Date Time\"}', 1, 1, '2021-11-03 16:00:00', '2023-12-11 06:25:57'),
('P2P_TRADE_PAID', 'P2P Trade Paid', 'Paid On Your Trade', '<div>Paid On Your Trade. Below are the trade Details</div><div><br></div><div>Order ID: {{order_id}},</div><div>Asset Amount: {{asset_amount}},</div><div>Fiat Amount: {{fiat_amount}},</div><div>Date: {{date}}<br></div>', 'Release On Your Trade. Below are the trade Details', '  {\"order_id\":\"Order ID of the trade\",\"asset_amount\":\"Buy/Sell asset amount\",\"fiat_amount\":\"Trade with this fiat amount\",\"asset\" :\"crypto currency symbol\",\"fiat\" :\"Fiat Currency Symbol\",\"date\":\"Trade Date Time\"}', 1, 1, '2021-11-03 16:00:00', '2023-12-11 06:14:47'),
('P2P_TRADE_RELEASE', 'P2P Trade Release', 'Release On Your Trade', '<div>Release On Your Trade. Below are the trade Details</div><div><br></div><div>Order ID: {{order_id}},</div><div>Asset Amount: {{asset_amount}},</div><div>Fiat Amount: {{fiat_amount}},</div><div>Date: {{date}}<br></div>', 'Release On Your Trade. Below are the trade Details', '  {\"order_id\":\"Order ID of the trade\",\"asset_amount\":\"Buy/Sell asset amount\",\"fiat_amount\":\"Trade with this fiat amount\",\"asset\" :\"crypto currency symbol\",\"fiat\" :\"Fiat Currency Symbol\",\"date\":\"Trade Date Time\"}', 1, 1, '2021-11-03 16:00:00', '2023-12-11 06:11:19'),
('P2P_TRADE_REPORT', 'P2P Trade Report', 'Report On Your Trade', '<div>Report On Your Trade. Below are the trade Details</div><div><br></div><div>Order ID: {{order_id}},</div><div>Asset Amount: {{asset_amount}},</div><div>Fiat Amount: {{fiat_amount}},</div><div>Date: {{date}}<br></div>', 'Report On Your Trade. Below are the trade Details', '{\"order_id\":\"Order ID of the trade\",\"asset_amount\":\"Buy/Sell asset amount\",\"fiat_amount\":\"Trade with this fiat amount\",\"asset\" :\"crypto currency symbol\",\"fiat\" :\"Fiat Currency Symbol\",\"date\":\"Trade Date Time\",\"report_date\":\"Reported Date Time\"}', 1, 1, '2021-11-03 16:00:00', '2023-12-11 06:08:01'),
('P2P_TRADE', 'P2P Trade', 'New Trade on Your Ad', '<div>New Trade on Your Ad. Below is trade Details</div><div><br></div><div>Order ID: {{order_id}},</div><div>Asset Amount: {{asset_amount}},</div><div>Fiat Amount: {{fiat_amount}},</div><div>Date: {{date}}<br></div>', 'New Trade on Your Ad. Below is trade Details.Order ID: {{order_id}},Asset Amount: {{asset_amount}},\r\nFiat Amount: {{fiat_amount}},Date: {{date}}', '{\"order_id\":\"Order ID of the trade\",\"asset_amount\":\"Buy/Sell asset amount\",\"fiat_amount\":\"Trade with this fiat amount\",\"asset\" :\"crypto currency symbol\",\"fiat\" :\"Fiat Currency Symbol\",\"date\":\"Trade Date Time\"}', 1, 1, '2021-11-03 16:00:00', '2023-12-11 05:43:28');

INSERT INTO `frontends` (`data_keys`, `data_values`, `tempname`, `created_at`, `updated_at`) VALUES
('p2p_how_to_work.element', '{\"heading\":\"Place an Order\",\"icon\":\"<i class=\\\"fas fa-clipboard-list\\\"><\\/i>\",\"small_description\":\"Once you place a P2P order, the crypto asset will be escrowed by Viserlab P2P.\",\"buy_or_sell\":\"buy\"}', 'basic', '2023-11-23 00:28:25', '2023-11-23 00:59:41'),
('p2p_how_to_work.element', '{\"heading\":\"Pay the Seller\",\"icon\":\"<i class=\\\"fas fa-clipboard-list\\\"><\\/i>\",\"small_description\":\"Send money to the seller via the suggested payment methods. Complete the fiat transaction and click \\\"Transferred, notify seller\\\" on Viserlab P2P.\",\"buy_or_sell\":\"buy\"}', 'basic', '2023-11-23 00:28:08', '2023-11-23 00:59:38'),
('p2p_how_to_work.element', '{\"heading\":\"Get your Crypto\",\"icon\":\"<i class=\\\"fas fa-clipboard-list\\\"><\\/i>\",\"small_description\":\"Once the seller confirms receipt of money, the escrowed crypto will be released to you.\",\"buy_or_sell\":\"buy\"}', 'basic', '2023-11-23 00:27:37', '2023-11-23 00:59:34'),
('p2p_how_to_work.element', '{\"heading\":\"Get your Crypto\",\"icon\":\"<i class=\\\"fas fa-coins\\\"><\\/i>\",\"small_description\":\"Once the seller confirms receipt of money, the escrowed crypto will be released to you.\",\"buy_or_sell\":\"sell\"}', 'basic', '2023-11-23 00:27:04', '2023-11-23 00:59:30'),
('p2p_how_to_work.element', '{\"heading\":\"Confirm the Payment\",\"icon\":\"<i class=\\\"far fa-check-circle\\\"><\\/i>\",\"small_description\":\"Send money to the seller via the suggested payment methods. Complete the fiat transaction and click \\\"Transferred, notify seller\\\" on Viserlab P2P.\",\"buy_or_sell\":\"sell\"}', 'basic', '2023-11-23 00:26:40', '2023-11-23 00:59:26'),
('p2p_how_to_work.element', '{\"heading\":\"Create an Order\",\"icon\":\"<i class=\\\"fas fa-clipboard-list\\\"><\\/i>\",\"small_description\":\"Place an Order and it will be listed on Cryptomus P2P Exchange page. The funds will be escrowed by the Exchange.\",\"buy_or_sell\":\"sell\"}', 'basic', '2023-11-23 00:23:47', '2023-11-23 00:59:23'),
('p2p_how_to_work.content', '{\"heading\":\"How {{ P2P Works}}\"}', 'basic', '2023-11-23 00:23:12', '2023-11-23 00:51:14'),
('p2p_banner.content', '{\"has_image\":\"1\",\"heading\":\"Trade Smarter Together: The {{P2P}} Trading Revolution Begins.\",\"subheading\":\"Buy and sell on P2P using your preferred payment\",\"image_one\":\"655e0355e3e7e1700660053.png\",\"image_two\":\"655e03562fb081700660054.png\"}', 'basic', '2023-11-22 07:32:28', '2023-11-22 07:34:14');

INSERT INTO `frontends` (`data_keys`, `data_values`, `tempname`, `created_at`, `updated_at`) VALUES
('p2p_banner.content', '{\"has_image\":\"1\",\"heading\":\"Trade Smarter Together: The {{P2P}} Trading Revolution Begins.\",\"subheading\":\"Buy and sell on P2P using your preferred payment\",\"image_one\":\"655e0355e3e7e1700660053.png\",\"image_two\":\"655e03562fb081700660054.png\"}', 'basic', '2023-11-22 01:32:28', '2023-11-22 01:34:14');


UPDATE `pages` SET `is_default` = '1' WHERE `pages`.`slug` = 'p2p';
UPDATE `currency_data_providers` SET `image` = 'coinmarketcap.jpg' WHERE `currency_data_providers`.`id` = 1;
