@extends('admin.layouts.master')
@section('title',__('user'))
@section('content')
<div class="card">
    <h1>dgdgdgdgdg</h1>
</div>
@endsection